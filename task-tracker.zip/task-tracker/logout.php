<?php
require __DIR__ . '/includes/bootstrap.php';

// Logout is a state-changing action, so it is POST-only and CSRF-protected.
require_post();
csrf_verify();

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

session_start();                       // fresh session just to carry the message
flash('success', 'You have been logged out.');
redirect('login.php');
