<?php
require __DIR__ . '/includes/bootstrap.php';

$user = require_login();
require_post();
csrf_verify();

$taskId = (int)($_POST['id'] ?? 0);
$status = (string)($_POST['status'] ?? '');
$back   = dashboard_url([
    'q'      => $_POST['q'] ?? '',
    'status' => $_POST['filter_status'] ?? '',
    'page'   => $_POST['page'] ?? 1,
]);

if (!in_array($status, STATUSES, true)) {
    flash('error', 'Invalid status selected.');
    redirect($back);
}

$task = find_accessible_task($taskId);      // backend ownership / role check
if ($task === null) {
    render_error(404, 'Task not found.');
}

if ($user['role'] === 'admin') {
    run('UPDATE tasks SET status = ? WHERE id = ?', [$status, (int)$task['id']]);
} else {
    run('UPDATE tasks SET status = ? WHERE id = ? AND user_id = ?', [$status, (int)$task['id'], (int)$user['id']]);
}

flash('success', 'Status of "' . $task['title'] . '" changed to ' . $status . '.');
redirect($back);
