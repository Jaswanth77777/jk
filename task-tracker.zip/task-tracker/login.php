<?php
require __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('dashboard.php');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $email    = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $user = run('SELECT id, password_hash FROM users WHERE email = ?', [$email])->fetch();

        // Always run password_verify (against a dummy hash if the user is unknown) so the
        // response time does not reveal whether an email is registered.
        $hash = $user['password_hash'] ?? '$2y$10$GIT5udSTQ8q2p8JDnsUJgeDXetDz1NQPq91XIyusae7EoIYUINp9W';
        $ok   = password_verify($password, $hash);

        if ($user && $ok) {
            if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
                run('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), (int)$user['id']]);
            }
            login_user((int)$user['id']);
            flash('success', 'Welcome back!');
            redirect('dashboard.php');
        }
        // One generic message: do not reveal whether the email or the password was wrong.
        $error = 'Invalid email or password.';
    }
}

$title = 'Log in';
require __DIR__ . '/includes/header.php';
?>
<div class="card narrow">
  <h1>Log in</h1>
  <?php if ($error): ?><div class="alert alert-error" role="alert"><?= e($error) ?></div><?php endif; ?>
  <form method="post" novalidate data-validate>
    <?= csrf_field() ?>
    <div class="field">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" required autocomplete="username" value="<?= e($email) ?>">
    </div>
    <div class="field">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required autocomplete="current-password">
    </div>
    <button type="submit" class="btn">Log in</button>
    <p class="muted">No account? <a href="register.php">Register</a></p>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
