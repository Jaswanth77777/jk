#!/usr/bin/env python3
"""
Optional automated HTTP tests (no extra packages needed).

It starts PHP's built-in web server against a throw-away SQLite database
(the app talks to the DB through PDO, so the same code runs on MySQL in production),
then exercises the app like a browser would.

Run from the project root:   python3 tests/smoke_test.py
"""
import http.cookiejar, os, re, sqlite3, subprocess, sys, tempfile, time, urllib.error, urllib.parse, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8765
BASE = f"http://127.0.0.1:{PORT}/"

SCHEMA = """
CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, description TEXT, status TEXT NOT NULL DEFAULT 'Pending'
  CHECK (status IN ('Pending','In Progress','Completed')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
"""

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else f"   <-- {detail}"))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar), NoRedirect())

    def req(self, path, data=None, follow=True):
        body = urllib.parse.urlencode(data).encode() if data is not None else None
        url = path if path.startswith("http") else BASE + path
        for _ in range(6):
            try:
                r = self.op.open(urllib.request.Request(url, data=body))
                return r.status, r.read().decode(), r.headers
            except urllib.error.HTTPError as e:
                if e.code in (301, 302, 303) and follow:
                    url = urllib.parse.urljoin(url, e.headers["Location"])
                    body = None
                    continue
                return e.code, e.read().decode(), e.headers
        raise RuntimeError("too many redirects")

    def token(self, path):
        _, html, _ = self.req(path)
        m = re.search(r'name="csrf_token" value="([0-9a-f]+)"', html)
        return m.group(1) if m else None

    def post(self, path, data, token_from=None, follow=True):
        data = dict(data)
        if "csrf_token" not in data:
            data["csrf_token"] = self.token(token_from or "dashboard.php")
        return self.req(path, data, follow)

    def login(self, email, pw):
        return self.post("login.php", {"email": email, "password": pw}, token_from="login.php")


def php_hash(pw):
    return subprocess.check_output(["php", "-r", f"echo password_hash({pw!r}, PASSWORD_DEFAULT);"]).decode()


def task_ids(html):
    return [int(x) for x in re.findall(r'task_form\.php\?id=(\d+)', html)]


def main():
    tmp = tempfile.mkdtemp()
    dbfile = os.path.join(tmp, "test.sqlite")
    con = sqlite3.connect(dbfile)
    con.executescript(SCHEMA)
    con.execute("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)",
                ("Admin", "admin@example.com", php_hash("Admin@123"), "admin"))
    con.commit()
    con.close()

    env = dict(os.environ, DB_DSN=f"sqlite:{dbfile}", DB_USER="", DB_PASS="")
    log = open(os.path.join(tmp, "server.log"), "w")
    srv = subprocess.Popen(["php", "-S", f"127.0.0.1:{PORT}", "-t", ROOT], env=env, stdout=log, stderr=log)
    time.sleep(1.2)
    try:
        run_tests(dbfile)
        test_broken_database()
    finally:
        srv.terminate()
        log.close()

    failed = [n for n, ok in results if not ok]
    print(f"\n{len(results) - len(failed)}/{len(results)} checks passed")
    sys.exit(1 if failed else 0)


def run_tests(dbfile):
    anon = Client()

    # ---- Level 3: access control for visitors ----
    s, body, _ = anon.req("dashboard.php")
    check("Logged-out visitor is redirected from dashboard to login", "<h1>Log in</h1>" in body)
    for p in ("task_form.php", "task_delete.php?id=1", "task_status.php"):
        s, body, _ = anon.req(p)
        check(f"Logged-out visitor cannot use {p}", "<h1>Log in</h1>" in body)

    # ---- Registration validation ----
    tok = anon.token("register.php")
    s, body, _ = anon.post("register.php", {"name": "", "email": "bad", "password": "abc", "confirm_password": "x", "csrf_token": tok})
    check("Register rejects empty name / bad email / weak password", all(t in body for t in ("Name is required", "valid email", "at least 8")))
    s, body, _ = anon.post("register.php", {"name": "Alice <b>", "email": "alice@example.com", "password": "Alice@123", "confirm_password": "Alice@123"}, token_from="register.php")
    check("Valid registration succeeds", "Account created" in body)
    s, body, _ = anon.post("register.php", {"name": "Dup", "email": "ALICE@example.com", "password": "Alice@123", "confirm_password": "Alice@123"}, token_from="register.php")
    check("Duplicate email (case-insensitive) is rejected", "already exists" in body)
    anon.post("register.php", {"name": "Bob", "email": "bob@example.com", "password": "Bob@12345", "confirm_password": "Bob@12345"}, token_from="register.php")

    con = sqlite3.connect(dbfile)
    hashes = [r[0] for r in con.execute("SELECT password_hash FROM users")]
    roles = dict(con.execute("SELECT email, role FROM users").fetchall())
    con.close()
    check("Passwords are stored as bcrypt hashes, not plain text", all(h.startswith("$2y$") for h in hashes) and not any("Alice@123" in h for h in hashes))
    check("Self-registered accounts get role 'user' (cannot self-promote)", roles["alice@example.com"] == "user")

    # ---- Login ----
    c = Client()
    s, body, _ = c.login("alice@example.com", "wrong-password1")
    check("Wrong password shows generic error", "Invalid email or password" in body)
    s, body, _ = c.login("nobody@example.com", "Whatever123")
    check("Unknown email shows the same generic error", "Invalid email or password" in body)
    s, body, _ = c.post("login.php", {"email": "alice@example.com", "password": "Alice@123", "csrf_token": "forged"}, token_from="login.php")
    check("Login with forged CSRF token is rejected (403)", s == 403)
    s, body, _ = c.login("alice@example.com", "Alice@123")
    check("Valid login reaches dashboard", "My tasks" in body and "Welcome back" in body)

    # ---- Level 1 + 2: CRUD & validation ----
    s, body, _ = c.post("task_form.php", {"title": "   ", "description": "x", "status": "Pending"}, token_from="task_form.php")
    check("Empty (whitespace) title is rejected by backend", "Title is required" in body)
    s, body, _ = c.post("task_form.php", {"title": "T" * 151, "description": "", "status": "Pending"}, token_from="task_form.php")
    check("Over-long title is rejected", "150 characters" in body)
    s, body, _ = c.post("task_form.php", {"title": "Valid", "description": "d", "status": "Hacked"}, token_from="task_form.php")
    check("Invalid status value is rejected", "valid status" in body)

    xss = '<script>alert(1)</script>'
    s, body, _ = c.post("task_form.php", {"title": "Write report " + xss, "description": "Line1\n" + xss, "status": "Pending"}, token_from="task_form.php")
    check("Add task shows success message", "was added successfully" in body)
    check("User-supplied HTML is escaped (XSS)", xss not in body and "&lt;script&gt;" in body)
    for t in ("Buy milk", "Plan sprint", "Report review"):
        c.post("task_form.php", {"title": t, "description": "", "status": "Pending"}, token_from="task_form.php")
    _, body, _ = c.req("dashboard.php")
    ids = task_ids(body)
    check("All 4 tasks are listed", len(ids) == 4, ids)
    alice_task = ids[-1]   # oldest = "Write report"

    s, body, _ = c.post("task_form.php?id=%d" % alice_task, {"id": alice_task, "title": "Write final report", "description": "updated", "status": "In Progress"}, token_from="task_form.php?id=%d" % alice_task)
    check("Edit task shows success message and new values", "was updated successfully" in body and "Write final report" in body)

    s, body, _ = c.post("task_status.php", {"id": alice_task, "status": "Completed", "q": "", "filter_status": "", "page": 1})
    check("Status change works and shows message", "changed to Completed" in body)
    s, body, _ = c.post("task_status.php", {"id": alice_task, "status": "Nonsense", "q": "", "filter_status": "", "page": 1})
    check("Invalid status on status endpoint is refused", "Invalid status" in body)

    _, body, _ = c.req("dashboard.php?q=report")
    check("Search by title finds matching tasks only", len(task_ids(body)) == 2 and "Buy milk" not in body, task_ids(body))
    _, body, _ = c.req("dashboard.php?q=%25")
    check("Search treats % literally (no wildcard match-all)", len(task_ids(body)) == 0)
    _, body, _ = c.req("dashboard.php?status=Completed")
    check("Status filter returns only Completed", task_ids(body) == [alice_task], task_ids(body))
    _, body, _ = c.req("dashboard.php?q=report&status=Completed")
    check("Search + filter combine", task_ids(body) == [alice_task])
    _, body, _ = c.req("dashboard.php?q=zzz")
    check("No-match search shows friendly message", "No tasks match" in body)
    _, body, _ = c.req("dashboard.php?q=%27+OR+1%3D1+--")
    check("SQL injection string in search is harmless", s == 200 and len(task_ids(body)) == 0)
    _, body, _ = c.req("dashboard.php")
    check("Dashboard summary counts correct (total 4, completed 1, pending 3)",
          re.search(r"<strong>4</strong><span>Total", body) and re.search(r"<strong>1</strong><span>Completed", body) and re.search(r"<strong>3</strong><span>Pending", body))

    # ---- Delete requires confirmation ----
    s, body, _ = c.req("task_delete.php?id=%d" % ids[0])
    check("GET on delete only shows a confirmation page", "Delete this task?" in body)
    _, body, _ = c.req("dashboard.php")
    check("...and the task still exists after the GET", ids[0] in task_ids(body))
    s, body, _ = c.post("task_delete.php", {"id": ids[0], "csrf_token": "forged"})
    check("Delete with forged CSRF token is refused", s == 403)
    s, body, _ = c.post("task_delete.php", {"id": ids[0]}, token_from="task_delete.php?id=%d" % ids[0])
    check("Confirmed delete works and shows message", "was deleted" in body and ids[0] not in task_ids(body))

    # ---- Authorization: Bob vs Alice ----
    b = Client()
    b.login("bob@example.com", "Bob@12345")
    _, body, _ = b.req("dashboard.php")
    check("Bob sees none of Alice's tasks", task_ids(body) == [] and "Write final report" not in body)
    s, body, _ = b.req("task_form.php?id=%d" % alice_task)
    check("Bob cannot open Alice's task by URL (404)", s == 404)
    s, body, _ = b.req("task_delete.php?id=%d" % alice_task)
    check("Bob cannot open delete page for Alice's task (404)", s == 404)
    s, body, _ = b.post("task_form.php?id=%d" % alice_task, {"id": alice_task, "title": "HACKED", "description": "", "status": "Pending"}, token_from="dashboard.php")
    check("Bob cannot edit Alice's task via forged POST (404)", s == 404)
    s, body, _ = b.post("task_status.php", {"id": alice_task, "status": "Pending", "q": "", "filter_status": "", "page": 1})
    check("Bob cannot change status of Alice's task (404)", s == 404)
    s, body, _ = b.post("task_delete.php", {"id": alice_task})
    check("Bob cannot delete Alice's task via forged POST (404)", s == 404)
    s, body, _ = b.post("task_form.php", {"user_id": 1, "title": "Bob task", "description": "", "status": "Pending"}, token_from="task_form.php")
    con = sqlite3.connect(dbfile)
    owner = con.execute("SELECT u.email FROM tasks t JOIN users u ON u.id=t.user_id WHERE t.title='Bob task'").fetchone()
    t = con.execute("SELECT title, status FROM tasks WHERE id=?", (alice_task,)).fetchone()
    con.close()
    check("Injected user_id in form is ignored (owner = logged-in user)", owner and owner[0] == "bob@example.com", owner)
    check("Alice's task is unchanged after Bob's attempts", t == ("Write final report", "Completed"), t)

    # ---- Admin role ----
    a = Client()
    a.login("admin@example.com", "Admin@123")
    _, body, _ = a.req("dashboard.php")
    check("Admin sees all users' tasks", "All users' tasks" in body and alice_task in task_ids(body) and "Bob task" in body)
    s, body, _ = a.post("task_status.php", {"id": alice_task, "status": "Pending", "q": "", "filter_status": "", "page": 1})
    check("Admin can change another user's task", "changed to Pending" in body)

    # ---- Pagination ----
    for i in range(12):
        c.post("task_form.php", {"title": f"Bulk {i}", "description": "", "status": "Pending"}, token_from="task_form.php")
    _, body, _ = c.req("dashboard.php")
    check("Pagination: first page shows 10 rows + pager", len(task_ids(body)) == 10 and "Page 1 of" in body, len(task_ids(body)))
    _, body, _ = c.req("dashboard.php?page=2")
    check("Pagination: page 2 has the rest", 0 < len(task_ids(body)) < 10 and "Page 2 of" in body)
    _, body, _ = c.req("dashboard.php?page=999")
    check("Out-of-range page is clamped safely", "Page 2 of" in body)

    # ---- Robustness / error handling ----
    s, body, _ = c.req("task_form.php?id=abc")
    check("Non-numeric id is treated as 'add' form (no crash)", s == 200 and "Add a task" in body)
    s, body, h = c.req("task_form.php?id=99999")
    check("Unknown task id gives friendly 404, no stack trace", s == 404 and "Task not found" in body and "Stack trace" not in body)
    s, body, _ = c.req("logout.php")
    check("Logout via GET is refused (POST-only)", s == 405)
    s, body, h = c.req("login.php")
    check("Security headers present", h.get("X-Frame-Options") == "DENY" and "default-src 'self'" in (h.get("Content-Security-Policy") or ""))
    s, body, _ = c.post("logout.php", {})
    _, body, _ = c.req("dashboard.php")
    check("Logout ends the session", "<h1>Log in</h1>" in body)


def test_broken_database():
    """DB unreachable -> friendly generic error; no credentials, host or stack trace shown."""
    env = dict(os.environ, DB_DSN="mysql:host=127.0.0.1;port=1;dbname=secretdb", DB_USER="secret_user", DB_PASS="secret_pass")
    srv = subprocess.Popen(["php", "-S", "127.0.0.1:8766", "-t", ROOT], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    try:
        c = Client()
        base = "http://127.0.0.1:8766/"
        _, html, _ = c.req(base + "login.php")
        tok = re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)
        code, body, _ = c.req(base + "login.php", {"email": "a@b.com", "password": "x", "csrf_token": tok})
        leaked = any(w in body for w in ("secret_user", "secret_pass", "secretdb", "127.0.0.1", "PDOException", "Stack trace", ".php:"))
        check("DB failure shows generic 500 page without credentials/paths", code == 500 and "Something went wrong" in body and not leaked, body[:200])
    finally:
        srv.terminate()


if __name__ == "__main__":
    main()
