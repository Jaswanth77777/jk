# Test cases & results

## A. Automated tests — `python3 tests/smoke_test.py`
Starts PHP's built-in server against a throw-away SQLite database (same PDO code path) and drives the app over HTTP like a browser.
**Result: 52 / 52 checks passed** (run on 2026-11-13, PHP 8.3).

> They ran on SQLite because no MySQL server was available where the app was built. Please also tick the manual checklist below on your own MySQL.

| # | Area | Test | Result |
|---|------|------|--------|
| 1 | Access | Logged-out visitor opening `dashboard.php`, `task_form.php`, `task_delete.php`, `task_status.php` is sent to login | Pass |
| 2 | Registration | Empty name / invalid email / weak password rejected | Pass |
| 3 | Registration | Valid sign-up works; duplicate email (any letter case) rejected | Pass |
| 4 | Passwords | Stored as `$2y$` bcrypt hashes, not plain text | Pass |
| 5 | Roles | Self-registered account always has role `user` | Pass |
| 6 | Login | Wrong password / unknown email → same generic error | Pass |
| 7 | CSRF | Login, delete with forged token → HTTP 403 | Pass |
| 8 | Validation | Whitespace-only title, 151-char title, invalid status all rejected server-side | Pass |
| 9 | Create | Task added, success message shown | Pass |
| 10 | XSS | `<script>` in title/description is escaped in output | Pass |
| 11 | Update | Edit saves new values + message; status change works + message | Pass |
| 12 | Status endpoint | Invalid status value refused | Pass |
| 13 | Search | Title search returns only matches; `%` treated literally | Pass |
| 14 | Filter | Status filter, and search + filter combined, return expected tasks | Pass |
| 15 | SQL injection | `' OR 1=1 --` in search → no rows, no error | Pass |
| 16 | Summary | Total/pending/in-progress/completed counts correct | Pass |
| 17 | Delete | GET only shows confirmation (task still exists); confirmed POST deletes + message | Pass |
| 18 | Authorization | Bob cannot open / edit / change status / delete Alice's task (URL or forged POST) → 404 | Pass |
| 19 | Authorization | Extra `user_id` field in the form is ignored; task owner = logged-in user | Pass |
| 20 | Authorization | Alice's task unchanged after Bob's attempts | Pass |
| 21 | Admin | Admin sees all tasks and can change another user's task | Pass |
| 22 | Pagination | 10 per page, page 2 shows the rest, page 999 is clamped | Pass |
| 23 | Robustness | `id=abc` and unknown id handled without crash/stack trace; logout via GET refused | Pass |
| 24 | Headers | CSP and X-Frame-Options present | Pass |
| 25 | Errors | Database unreachable → generic 500 page; no DB name, user, password, host, or file path in the output | Pass |

## B. Assignment checklist (section 8) — manual, tick on your MySQL
- [ ] Can a user add a task with valid information?
- [ ] Does the application reject an empty task title? (try with JS disabled too)
- [ ] Can a user edit, update status and delete a task?
- [ ] Do search and status filters return the expected tasks?
- [ ] Can a logged-out visitor access the dashboard directly? (must not)
- [ ] Are passwords stored as hashes? (`SELECT password_hash FROM users;` in phpMyAdmin)
- [ ] Can a user access or modify another user's tasks? (log in as Alice, open `task_form.php?id=<Bob's task id>` → 404)
- [ ] Do database operations use prepared statements? (see `run()` in `includes/bootstrap.php`)
- [ ] Invalid input doesn't reveal DB credentials/raw errors (stop MySQL and reload a page → generic error)

## C. Bugs found and fixed while building
1. **Placeholder dummy hash in login.php was not a valid bcrypt string**, so `password_verify` would have returned instantly for unknown emails (timing leak). Replaced with a real hash.
2. **`LIKE ... ESCAPE '\\'` is not portable** (MySQL and SQLite treat the backslash differently). Switched to `ESCAPE '!'`, which behaves the same everywhere.
3. **LIMIT/OFFSET with native prepared statements** fail in MySQL if bound as strings; `run()` now binds integers with `PDO::PARAM_INT`.
4. Screenshot script initially clicked the header's *Log out* button instead of the form's submit button (test-script bug, not an app bug).

## D. Screenshots
See the `screenshots/` folder (register, login validation, dashboard, add-task validation error, success message, status change, search + filter, delete confirmation, blocked access to another user's task, admin dashboard, mobile layout).
