-- Task Tracker database (MySQL 5.7+ / MariaDB 10.3+)
-- Import:  mysql -u root -p < database.sql
-- Or use phpMyAdmin -> Import.

CREATE DATABASE IF NOT EXISTS task_tracker
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE task_tracker;

DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS users;

-- Users: 'role' decides what a person may do (see README "Roles & permissions").
CREATE TABLE users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(100)  NOT NULL,
  email         VARCHAR(150)  NOT NULL,
  password_hash VARCHAR(255)  NOT NULL,            -- output of password_hash(); never plain text
  role          ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tasks: every task belongs to exactly one user (ownership check is based on user_id).
CREATE TABLE tasks (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  title       VARCHAR(150) NOT NULL,
  description TEXT         NULL,
  status      ENUM('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
  created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_tasks_user_status (user_id, status),
  KEY idx_tasks_title (title),
  CONSTRAINT fk_tasks_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- Sample data (TEST ONLY - change/remove before any real use)
--   admin@example.com / Admin@123   (role: admin)
--   alice@example.com / Alice@123   (role: user)
--   bob@example.com   / Bob@12345   (role: user)
-- Passwords below are bcrypt hashes created with PHP password_hash().
-- ---------------------------------------------------------------
INSERT INTO users (id, name, email, password_hash, role) VALUES
  (1, 'Admin User', 'admin@example.com', '$2y$10$0iBwGugx3T8rkNgSUfu1M.u0dGxKsMZX1f5KgqK5CvVyOQ5j0df12', 'admin'),
  (2, 'Alice',      'alice@example.com', '$2y$10$0kj/gZFRvjeYb.zBrMDLV.lyzj8UJyHzjnRmSVwcca4GvP8YUtkiK', 'user'),
  (3, 'Bob',        'bob@example.com',   '$2y$10$dhSiS1LU5VSJ1G8cRF8E0O2wrRKj7Bli7dl240FtazzgJHhwLMCRm', 'user');

INSERT INTO tasks (user_id, title, description, status) VALUES
  (2, 'Prepare project report',  'Collect figures and write the summary section.', 'In Progress'),
  (2, 'Buy lab components',      'Resistors, breadboard and jumper wires.',        'Pending'),
  (2, 'Submit internship form',  'Upload signed copy to the portal.',              'Completed'),
  (3, 'Fix login page bug',      'Error message not shown for wrong password.',    'Pending'),
  (3, 'Review pull request #12', NULL,                                              'In Progress'),
  (1, 'Check weekly backups',    'Verify the latest database dump restores.',      'Pending');
