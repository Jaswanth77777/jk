/* Frontend helpers. The server ALWAYS re-validates; this only gives faster feedback. */
(function () {
  'use strict';

  // Status dropdowns on the dashboard submit as soon as they change.
  document.querySelectorAll('select[data-autosubmit]').forEach(function (sel) {
    sel.addEventListener('change', function () { sel.form.submit(); });
  });

  // Client-side validation for forms marked with data-validate.
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      var firstBad = null;

      form.querySelectorAll('.js-error').forEach(function (n) { n.remove(); });
      form.querySelectorAll('.invalid').forEach(function (n) { n.classList.remove('invalid'); });

      form.querySelectorAll('input[required], textarea[required]').forEach(function (el) {
        var msg = '';
        var val = el.value.trim();
        var label = form.querySelector('label[for="' + el.id + '"]');
        var name = label ? label.textContent.replace('*', '').trim() : 'This field';

        if (val === '') {
          msg = name + ' is required.';
        } else if (el.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
          msg = 'Please enter a valid email address.';
        } else if (el.minLength > 0 && el.value.length < el.minLength) {
          msg = name + ' must be at least ' + el.minLength + ' characters.';
        }

        if (msg) {
          var p = document.createElement('p');
          p.className = 'field-error js-error';
          p.textContent = msg;
          el.classList.add('invalid');
          el.parentNode.appendChild(p);
          if (!firstBad) { firstBad = el; }
        }
      });

      var pw = form.querySelector('#password');
      var cf = form.querySelector('#confirm_password');
      if (pw && cf && !firstBad && pw.value !== cf.value) {
        var p2 = document.createElement('p');
        p2.className = 'field-error js-error';
        p2.textContent = 'Passwords do not match.';
        cf.classList.add('invalid');
        cf.parentNode.appendChild(p2);
        firstBad = cf;
      }

      if (firstBad) {
        ev.preventDefault();
        firstBad.focus();
      }
    });
  });
})();
