# Task Tracker (PHP + MySQL)

A simple multi-user task manager built for the RTIH Intern (IT) technical assignment.
Plain PHP 8 (no framework), PDO + MySQL/MariaDB, and hand-written HTML/CSS/JS (no CDN, works offline).

**Levels completed:** Level 1 ✅ Level 2 ✅ Level 3 ✅ — plus bonus: pagination and dashboard summary.

---

## 1. Setup

### Requirements
- PHP 8.1+ with the `pdo_mysql` extension (enabled by default in XAMPP/WAMP/MAMP)
- MySQL 5.7+ or MariaDB 10.3+

### Steps (XAMPP example)
1. Copy the `task-tracker` folder into `C:\xampp\htdocs\` (or `/var/www/html/`).
2. Start **Apache** and **MySQL** in the XAMPP control panel.
3. Import the database — either:
   - phpMyAdmin → *Import* → choose `database.sql` → *Go*, or
   - command line: `mysql -u root -p < database.sql`

   This creates the `task_tracker` database, both tables and sample data.
4. Check the database settings in `config.php`. Defaults are XAMPP's: user `root`, **empty** password, host `127.0.0.1`, database `task_tracker`.
   If yours differ, **set environment variables instead of editing the file** so credentials never end up in the code:
   `DB_DSN`, `DB_USER`, `DB_PASS`
   (e.g. `DB_DSN="mysql:host=127.0.0.1;dbname=task_tracker;charset=utf8mb4"`).
5. Open **http://localhost/task-tracker/** in a browser.

### Quick run without Apache
```bash
php -S localhost:8000          # run inside the task-tracker folder
# then open http://localhost:8000
```

### Test logins (from `database.sql` — sample data only)
| Role  | Email               | Password    |
|-------|---------------------|-------------|
| admin | admin@example.com   | `Admin@123` |
| user  | alice@example.com   | `Alice@123` |
| user  | bob@example.com     | `Bob@12345` |

You can also create your own account on the **Register** page (it always creates a normal `user`).

---

## 2. Features

| Level | Feature | Where |
|------|---------|-------|
| 1 | Create DB + `tasks` table | `database.sql` |
| 1 | Add / list / edit tasks | `task_form.php`, `dashboard.php` |
| 1 | Delete **after confirmation** (separate confirm page) | `task_delete.php` |
| 1 | Success messages for add / update / delete | flash messages (`includes/bootstrap.php`) |
| 2 | Status: Pending / In Progress / Completed, changeable from the list or the edit form | `task_status.php` |
| 2 | Search by title + status filter (combinable) | `dashboard.php` |
| 2 | Validation on frontend (`assets/app.js`, HTML attributes) **and** backend (`validate_task()`), friendly errors | |
| 3 | Registration + login/logout, `password_hash()` / `password_verify()` | `register.php`, `login.php`, `logout.php` |
| 3 | Dashboard only for logged-in users | `require_login()` |
| 3 | Roles + ownership authorization enforced in the backend | `find_accessible_task()` |
| 3 | Prepared statements everywhere (PDO, native prepares) | `run()` in `includes/bootstrap.php` |
| 3 | Output escaping (`e()` → `htmlspecialchars`) | all views |
| 3 | CSRF tokens on every state-changing form | `csrf_token()`, `csrf_verify()` |
| Bonus | Pagination (10 per page) and summary tiles (total / pending / in progress / completed) | `dashboard.php` |

---

## 3. Roles & permissions

| Action | Guest | `user` | `admin` |
|--------|:----:|:------:|:-------:|
| Register / log in | ✅ | – | – |
| View dashboard | ❌ → redirected to login | ✅ own tasks only | ✅ all users' tasks |
| Add task | ❌ | ✅ (always owned by themselves) | ✅ (owned by themselves) |
| Edit / change status / delete a task | ❌ | ✅ **only their own** | ✅ any task |

**Rules and why:**
- Every task has a `user_id` (owner). The owner is taken from the **session**, never from form data, so a user cannot create tasks for someone else by tampering with the request.
- `find_accessible_task($id)` is used by *every* task page (edit, status, delete). It returns the task only if the user is the owner **or** an admin; otherwise the app answers with a plain **404** — the same response as for a non-existent ID, so IDs can't be probed.
- Update/delete queries also contain `AND user_id = ?` for normal users (defence in depth).
- Authorization is enforced **in PHP**, not by hiding buttons.
- Admins are created only in the database (self-registration can never grant admin). The admin role exists so the "role" part of authorization is demonstrable; it is deliberately small (no user-management screens).
- Role is re-read from the database on each request, so changing/removing a user takes effect immediately.

---

## 4. Database design

```
users                                   tasks
-----                                   -----
id            INT PK AUTO_INCREMENT     id          INT PK AUTO_INCREMENT
name          VARCHAR(100)              user_id     INT  FK -> users.id  (ON DELETE CASCADE)
email         VARCHAR(150) UNIQUE       title       VARCHAR(150) NOT NULL
password_hash VARCHAR(255)              description TEXT NULL
role          ENUM('user','admin')      status      ENUM('Pending','In Progress','Completed') DEFAULT 'Pending'
created_at    TIMESTAMP                 created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```
- **One-to-many** (one user → many tasks) via a foreign key; deleting a user removes their tasks (`CASCADE`).
- `email` is `UNIQUE` (also protects against double sign-up races).
- `password_hash VARCHAR(255)` leaves room for future hashing algorithms (bcrypt is 60 chars today).
- `ENUM` for `status`/`role` lets the database itself reject invalid values (the app validates too).
- Index on `(user_id, status)` speeds up "my tasks by status"; index on `title` helps search.
- `utf8mb4` so emoji/any language can be stored.

---

## 5. Security measures (Level 3 checklist)

- **Passwords:** `password_hash(PASSWORD_DEFAULT)` / `password_verify()`; never stored or logged in plain text. Login uses one generic error ("Invalid email or password") and runs `password_verify` even for unknown emails (equalises timing).
- **Session:** `HttpOnly` + `SameSite=Lax` cookie, `session_regenerate_id(true)` on login (prevents fixation), proper session destruction on logout.
- **SQL injection:** only prepared statements with bound parameters (`run()`); `LIMIT`/`OFFSET` are bound as integers; `LIKE` wildcards typed by the user (`%`, `_`) are escaped.
- **XSS:** every user-provided value is output through `e()`; also a strict `Content-Security-Policy` (no inline scripts/styles, no external resources).
- **CSRF:** a random per-session token in every POST form, checked with `hash_equals()`. Logout and delete are POST-only; the delete link (GET) only shows a confirmation page and never changes data.
- **Authorization / IDOR:** see section 3.
- **Errors:** `display_errors` is off; uncaught exceptions are logged server-side and the visitor sees a generic "Something went wrong" page (no credentials, paths or SQL).
- **Headers:** `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, CSP.

---

## 6. Known limitations
- No login rate-limiting / account lockout (brute force is possible). A production app should add it.
- No password reset, email verification or "remember me".
- No admin user-management screen; the admin account comes from `database.sql`. **Change/remove the sample accounts before real use.**
- The session cookie's `Secure` flag is applied automatically only when the site is served over HTTPS — use HTTPS in production.
- Automated tests ran against SQLite through PDO because no MySQL server was available in the build environment; the SQL is standard and the schema is MySQL-specific (`ENUM`, `AUTO_INCREMENT`). **Please run the manual checklist once against your own MySQL** (see `TESTING.md`).
- Search matches title only (as required), not description.

---

## 7. Database backup and restore
**Backup** (creates a plain-SQL dump):
```bash
mysqldump -u root -p --single-transaction --routines task_tracker > backup_$(date +%F).sql
```
**Restore** (into an empty or existing database):
```bash
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS task_tracker CHARACTER SET utf8mb4"
mysql -u root -p task_tracker < backup_2026-11-13.sql
```
Alternatively use phpMyAdmin → *Export* / *Import*. In practice: schedule `mysqldump` daily (cron / Task Scheduler), keep several generations, store copies off the server, and **test a restore** periodically. `database.sql` itself recreates a fresh database (it drops existing tables, so don't use it to "restore" real data).

---

## 8. AI assistant disclosure
- **Tool used:** Claude (Anthropic) was used to generate the initial code, documentation and the automated test script.
-- **One change after reviewing the generated code:** In `csrf_verify()`
  (`includes/bootstrap.php`), I found that [WHAT THE BUG WAS]. I changed it so that
  [WHAT YOU CHANGED]. I tested it by [HOW YOU TESTED IT].
---

## 9. Project structure
```
task-tracker/
├── index.php            redirects to login/dashboard
├── register.php  login.php  logout.php
├── dashboard.php        list + search + filter + pagination + summary
├── task_form.php        add / edit (one form, two modes)
├── task_status.php      change status (POST)
├── task_delete.php      confirmation page (GET) + delete (POST)
├── config.php           DB settings (env-var overridable)
├── database.sql         schema + sample data
├── includes/            bootstrap.php (DB, session, CSRF, auth, validation), header.php, footer.php
├── assets/              style.css, app.js
├── tests/smoke_test.py  optional automated HTTP tests
├── screenshots/         screenshots of the working app
├── TESTING.md           test cases and results
└── README.md
```
