<?php
require __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('dashboard.php');
}

$errors = [];
$old = ['name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $name     = trim((string)($_POST['name'] ?? ''));
    $email    = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $confirm  = (string)($_POST['confirm_password'] ?? '');
    $old      = ['name' => $name, 'email' => $email];

    if ($name === '' || mb_strlen($name) > 100) {
        $errors['name'] = 'Name is required (max 100 characters).';
    }
    if ($email === '' || mb_strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors['password'] = 'Password must be at least 8 characters and include a letter and a number.';
    } elseif (strlen($password) > 72) {
        $errors['password'] = 'Password must be 72 characters or fewer.';   // bcrypt limit
    }
    if (!isset($errors['password']) && $password !== $confirm) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }

    if (!$errors) {
        $exists = run('SELECT id FROM users WHERE email = ?', [$email])->fetch();
        if ($exists) {
            $errors['email'] = 'An account with this email already exists.';
        } else {
            try {
                // Self-registration ALWAYS creates a normal "user"; admins are created in the database only.
                run('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
                    [$name, $email, password_hash($password, PASSWORD_DEFAULT), 'user']);
            } catch (PDOException $ex) {
                // Race condition: two sign-ups with the same email at once (unique key rejects the 2nd).
                error_log('[TaskTracker] register: ' . $ex->getMessage());
                $errors['email'] = 'An account with this email already exists.';
            }
            if (!$errors) {
                flash('success', 'Account created. You can now log in.');
                redirect('login.php');
            }
        }
    }
}

$title = 'Register';
require __DIR__ . '/includes/header.php';
?>
<div class="card narrow">
  <h1>Create an account</h1>
  <form method="post" novalidate data-validate>
    <?= csrf_field() ?>
    <div class="field">
      <label for="name">Name</label>
      <input type="text" id="name" name="name" maxlength="100" required value="<?= e($old['name']) ?>">
      <?php if (isset($errors['name'])): ?><p class="field-error"><?= e($errors['name']) ?></p><?php endif; ?>
    </div>
    <div class="field">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" maxlength="150" required value="<?= e($old['email']) ?>">
      <?php if (isset($errors['email'])): ?><p class="field-error"><?= e($errors['email']) ?></p><?php endif; ?>
    </div>
    <div class="field">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" minlength="8" maxlength="72" required autocomplete="new-password">
      <small>At least 8 characters, with a letter and a number.</small>
      <?php if (isset($errors['password'])): ?><p class="field-error"><?= e($errors['password']) ?></p><?php endif; ?>
    </div>
    <div class="field">
      <label for="confirm_password">Confirm password</label>
      <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password">
      <?php if (isset($errors['confirm_password'])): ?><p class="field-error"><?= e($errors['confirm_password']) ?></p><?php endif; ?>
    </div>
    <button type="submit" class="btn">Register</button>
    <p class="muted">Already registered? <a href="login.php">Log in</a></p>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
