<?php
/**
 * Application configuration.
 *
 * Defaults match a fresh XAMPP/WAMP install (user "root", empty password).
 * For anything else, set environment variables instead of editing this file,
 * so that real credentials are never committed or submitted:
 *   DB_DSN, DB_USER, DB_PASS
 */
return [
    'db' => [
        'dsn'  => getenv('DB_DSN')  ?: 'mysql:host=127.0.0.1;port=3306;dbname=task_tracker;charset=utf8mb4',
        'user' => getenv('DB_USER') !== false ? getenv('DB_USER') : 'root',
        'pass' => getenv('DB_PASS') !== false ? getenv('DB_PASS') : '',
    ],
    'per_page' => 10,
];
