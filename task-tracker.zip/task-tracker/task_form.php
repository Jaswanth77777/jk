<?php
require __DIR__ . '/includes/bootstrap.php';

$user = require_login();

/* Edit mode: load the task only if the current user may access it (ownership / admin check in the backend). */
$taskId = isset($_GET['id']) ? (int)$_GET['id'] : (int)($_POST['id'] ?? 0);
$task   = null;
if ($taskId > 0) {
    $task = find_accessible_task($taskId);
    if ($task === null) {
        render_error(404, 'Task not found.');
    }
}
$isEdit = $task !== null;

$errors = [];
$values = $isEdit
    ? ['title' => $task['title'], 'description' => (string)$task['description'], 'status' => $task['status']]
    : ['title' => '', 'description' => '', 'status' => 'Pending'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    [$values, $errors] = validate_task($_POST);

    if (!$errors) {
        if ($isEdit) {
            // user_id in the WHERE clause = second line of defence behind find_accessible_task().
            if ($user['role'] === 'admin') {
                run('UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ?',
                    [$values['title'], $values['description'], $values['status'], (int)$task['id']]);
            } else {
                run('UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ? AND user_id = ?',
                    [$values['title'], $values['description'], $values['status'], (int)$task['id'], (int)$user['id']]);
            }
            flash('success', 'Task "' . $values['title'] . '" was updated successfully.');
        } else {
            // The owner always comes from the session, never from form data.
            run('INSERT INTO tasks (user_id, title, description, status) VALUES (?, ?, ?, ?)',
                [(int)$user['id'], $values['title'], $values['description'], $values['status']]);
            flash('success', 'Task "' . $values['title'] . '" was added successfully.');
        }
        redirect('dashboard.php');
    }
}

$title = $isEdit ? 'Edit task' : 'Add task';
require __DIR__ . '/includes/header.php';
?>
<div class="card narrow">
  <h1><?= $isEdit ? 'Edit task' : 'Add a task' ?></h1>
  <?php if ($errors): ?>
    <div class="alert alert-error" role="alert">Please fix the highlighted problem<?= count($errors) > 1 ? 's' : '' ?> below.</div>
  <?php endif; ?>
  <form method="post" action="task_form.php<?= $isEdit ? '?id=' . (int)$task['id'] : '' ?>" novalidate data-validate>
    <?= csrf_field() ?>
    <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int)$task['id'] ?>"><?php endif; ?>

    <div class="field <?= isset($errors['title']) ? 'has-error' : '' ?>">
      <label for="title">Title <span class="req">*</span></label>
      <input type="text" id="title" name="title" maxlength="150" required value="<?= e($values['title']) ?>">
      <?php if (isset($errors['title'])): ?><p class="field-error"><?= e($errors['title']) ?></p><?php endif; ?>
    </div>

    <div class="field <?= isset($errors['description']) ? 'has-error' : '' ?>">
      <label for="description">Description</label>
      <textarea id="description" name="description" rows="5" maxlength="2000"><?= e($values['description']) ?></textarea>
      <?php if (isset($errors['description'])): ?><p class="field-error"><?= e($errors['description']) ?></p><?php endif; ?>
    </div>

    <div class="field <?= isset($errors['status']) ? 'has-error' : '' ?>">
      <label for="status">Status</label>
      <select id="status" name="status">
        <?php foreach (STATUSES as $s): ?>
          <option value="<?= e($s) ?>" <?= $s === $values['status'] ? 'selected' : '' ?>><?= e($s) ?></option>
        <?php endforeach; ?>
      </select>
      <?php if (isset($errors['status'])): ?><p class="field-error"><?= e($errors['status']) ?></p><?php endif; ?>
    </div>

    <div class="actions">
      <button type="submit" class="btn"><?= $isEdit ? 'Save changes' : 'Add task' ?></button>
      <a class="btn btn-ghost" href="dashboard.php">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
