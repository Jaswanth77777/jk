<?php
require __DIR__ . '/includes/bootstrap.php';

$user    = require_login();      // logged-out visitors are redirected to the login page
$isAdmin = $user['role'] === 'admin';

/* ---------- Read & sanitise filters ---------- */
$q            = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 100);
$statusFilter = (string)($_GET['status'] ?? '');
if (!in_array($statusFilter, STATUSES, true)) {
    $statusFilter = '';
}
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)$GLOBALS['config']['per_page'];

/* ---------- Build WHERE (every value is a bound parameter) ---------- */
$where  = [];
$params = [];
if (!$isAdmin) {
    $where[]  = 't.user_id = ?';          // ownership: normal users only ever see their own tasks
    $params[] = (int)$user['id'];
}
if ($q !== '') {
    // Escape LIKE wildcards so a search for "100%" or "a_b" is treated literally.
    $like     = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $q) . '%';
    $where[]  = "t.title LIKE ? ESCAPE '!'";
    $params[] = $like;
}
if ($statusFilter !== '') {
    $where[]  = 't.status = ?';
    $params[] = $statusFilter;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* ---------- Pagination ---------- */
$total      = (int)run("SELECT COUNT(*) FROM tasks t $whereSql", $params)->fetchColumn();
$totalPages = max(1, (int)ceil($total / $perPage));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * $perPage;

$tasks = run(
    "SELECT t.id, t.user_id, t.title, t.description, t.status, t.created_at, u.name AS owner_name
       FROM tasks t JOIN users u ON u.id = t.user_id
       $whereSql
      ORDER BY t.created_at DESC, t.id DESC
      LIMIT ? OFFSET ?",
    array_merge($params, [$perPage, $offset])
)->fetchAll();

/* ---------- Summary counts (not affected by search/filter) ---------- */
$summary = ['Pending' => 0, 'In Progress' => 0, 'Completed' => 0];
$sumSql  = 'SELECT status, COUNT(*) AS c FROM tasks' . ($isAdmin ? '' : ' WHERE user_id = ?') . ' GROUP BY status';
foreach (run($sumSql, $isAdmin ? [] : [(int)$user['id']])->fetchAll() as $row) {
    $summary[$row['status']] = (int)$row['c'];
}
$summaryTotal = array_sum($summary);

$current = ['q' => $q, 'status' => $statusFilter, 'page' => $page];

$title = 'Dashboard';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <h1><?= $isAdmin ? "All users' tasks" : 'My tasks' ?></h1>
  <a class="btn" href="task_form.php">+ Add task</a>
</div>
<?php if ($isAdmin): ?>
  <p class="muted">You are an administrator, so you can see and manage every user's tasks.</p>
<?php endif; ?>

<section class="summary" aria-label="Task summary">
  <div class="stat"><strong><?= $summaryTotal ?></strong><span>Total</span></div>
  <div class="stat s-pending"><strong><?= $summary['Pending'] ?></strong><span>Pending</span></div>
  <div class="stat s-progress"><strong><?= $summary['In Progress'] ?></strong><span>In Progress</span></div>
  <div class="stat s-done"><strong><?= $summary['Completed'] ?></strong><span>Completed</span></div>
</section>

<form method="get" action="dashboard.php" class="filters">
  <div class="field grow">
    <label for="q">Search by title</label>
    <input type="search" id="q" name="q" maxlength="100" placeholder="e.g. report" value="<?= e($q) ?>">
  </div>
  <div class="field">
    <label for="status">Status</label>
    <select id="status" name="status">
      <option value="">All statuses</option>
      <?php foreach (STATUSES as $s): ?>
        <option value="<?= e($s) ?>" <?= $s === $statusFilter ? 'selected' : '' ?>><?= e($s) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field actions">
    <button type="submit" class="btn">Apply</button>
    <?php if ($q !== '' || $statusFilter !== ''): ?><a class="btn btn-ghost" href="dashboard.php">Clear</a><?php endif; ?>
  </div>
</form>

<?php if (!$tasks): ?>
  <div class="card empty">
    <?php if ($q !== '' || $statusFilter !== ''): ?>
      <p>No tasks match your search or filter.</p>
    <?php else: ?>
      <p>No tasks yet. Click <strong>Add task</strong> to create your first one.</p>
    <?php endif; ?>
  </div>
<?php else: ?>
  <div class="table-wrap">
    <table class="tasks">
      <thead>
        <tr>
          <th>Title</th>
          <th>Description</th>
          <?php if ($isAdmin): ?><th>Owner</th><?php endif; ?>
          <th>Status</th>
          <th>Created</th>
          <th class="col-actions">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($tasks as $t): ?>
        <tr>
          <td data-label="Title"><strong><?= e($t['title']) ?></strong></td>
          <td data-label="Description" class="desc"><?= $t['description'] !== null && $t['description'] !== '' ? nl2br(e($t['description'])) : '<span class="muted">-</span>' ?></td>
          <?php if ($isAdmin): ?><td data-label="Owner"><?= e($t['owner_name']) ?></td><?php endif; ?>
          <td data-label="Status">
            <form method="post" action="task_status.php" class="status-form">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <input type="hidden" name="q" value="<?= e($q) ?>">
              <input type="hidden" name="filter_status" value="<?= e($statusFilter) ?>">
              <input type="hidden" name="page" value="<?= (int)$page ?>">
              <label class="sr-only" for="st<?= (int)$t['id'] ?>">Status for <?= e($t['title']) ?></label>
              <select id="st<?= (int)$t['id'] ?>" name="status" class="badge-select st-<?= e(strtolower(str_replace(' ', '-', $t['status']))) ?>" data-autosubmit>
                <?php foreach (STATUSES as $s): ?>
                  <option value="<?= e($s) ?>" <?= $s === $t['status'] ? 'selected' : '' ?>><?= e($s) ?></option>
                <?php endforeach; ?>
              </select>
              <noscript><button type="submit" class="btn btn-small">Save</button></noscript>
            </form>
          </td>
          <td data-label="Created"><?= e(date('d M Y, H:i', strtotime((string)$t['created_at']))) ?></td>
          <td data-label="Actions" class="col-actions">
            <a class="btn btn-small" href="task_form.php?id=<?= (int)$t['id'] ?>">Edit</a>
            <a class="btn btn-small btn-danger" href="task_delete.php?id=<?= (int)$t['id'] ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($totalPages > 1): ?>
    <nav class="pager" aria-label="Pagination">
      <?php if ($page > 1): ?><a class="btn btn-small btn-ghost" href="<?= e(dashboard_url(['q' => $q, 'status' => $statusFilter, 'page' => $page - 1])) ?>">&laquo; Prev</a><?php endif; ?>
      <span>Page <?= $page ?> of <?= $totalPages ?> &middot; <?= $total ?> task<?= $total === 1 ? '' : 's' ?></span>
      <?php if ($page < $totalPages): ?><a class="btn btn-small btn-ghost" href="<?= e(dashboard_url(['q' => $q, 'status' => $statusFilter, 'page' => $page + 1])) ?>">Next &raquo;</a><?php endif; ?>
    </nav>
  <?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
