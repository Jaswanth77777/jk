<?php
declare(strict_types=1);

/**
 * Shared bootstrap: error handling, session, database, helpers, CSRF, auth.
 * Every page includes this file first.
 */

// Never show raw errors to visitors (they could leak paths or DB details); log them instead.
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

const STATUSES = ['Pending', 'In Progress', 'Completed'];

$GLOBALS['config'] = require __DIR__ . '/../config.php';

/* ---------- Security headers ---------- */
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'; form-action 'self'");

/* ---------- Session ---------- */
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => !empty($_SERVER['HTTPS']),
    'httponly' => true,       // JavaScript cannot read the session cookie
    'samesite' => 'Lax',
]);
session_name('tasktracker_sid');
session_start();

/* ---------- Generic error handling ---------- */
function render_error(int $code, string $message): void
{
    http_response_code($code);
    $title = 'Error ' . $code;
    require __DIR__ . '/header.php';
    echo '<div class="card narrow"><h1>' . e($title) . '</h1><p>' . e($message) . '</p>'
       . '<p><a class="btn" href="dashboard.php">Back to dashboard</a></p></div>';
    require __DIR__ . '/footer.php';
    exit;
}

set_exception_handler(function (Throwable $ex): void {
    error_log('[TaskTracker] ' . get_class($ex) . ': ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    if (!headers_sent()) {
        render_error(500, 'Something went wrong. Please try again later.');
    }
    exit;
});

/* ---------- Output escaping ---------- */
function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* ---------- Database (PDO, prepared statements only) ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = $GLOBALS['config']['db'];
        $pdo = new PDO($c['dsn'], $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,   // real prepared statements
        ]);
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
            $pdo->exec('PRAGMA foreign_keys = ON');   // only used by the automated tests
        }
    }
    return $pdo;
}

/** Prepare + bind + execute. Integers are bound as integers (needed for LIMIT/OFFSET). */
function run(string $sql, array $params = []): PDOStatement
{
    $stmt = db()->prepare($sql);
    foreach (array_values($params) as $i => $value) {
        $stmt->bindValue($i + 1, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
    }
    $stmt->execute();
    return $stmt;
}

/* ---------- Flash messages ---------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function take_flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/* ---------- CSRF protection (synchroniser token) ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/** Call at the top of every POST handler. */
/** Call at the top of every POST handler. */
function csrf_verify(): void
{
    $sent = $_POST['csrf_token'] ?? '';
    $expected = $_SESSION['csrf'] ?? '';

    // Reject if either token is missing/empty, so '' can never equal ''
    if (!is_string($sent) || $sent === '' || $expected === '' || !hash_equals($expected, $sent)) {
        render_error(403, 'Your form session expired or was invalid. Please go back and try again.');
    }
}

function require_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        render_error(405, 'This action must be submitted from a form.');
    }
}

/* ---------- Authentication & authorization ---------- */
function current_user(): ?array
{
    static $user = false;
    if ($user === false) {
        $user = null;
        if (!empty($_SESSION['user_id'])) {
            // Re-read from DB each request so role changes / deleted accounts take effect immediately.
            $row = run('SELECT id, name, email, role FROM users WHERE id = ?', [(int)$_SESSION['user_id']])->fetch();
            $user = $row ?: null;
            if ($user === null) {
                unset($_SESSION['user_id']);
            }
        }
    }
    return $user;
}

function require_login(): array
{
    $user = current_user();
    if ($user === null) {
        flash('error', 'Please log in to continue.');
        redirect('login.php');
    }
    return $user;
}

function is_admin(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'admin';
}

function login_user(int $userId): void
{
    session_regenerate_id(true);       // prevents session fixation
    $_SESSION['user_id'] = $userId;
    unset($_SESSION['csrf']);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

/**
 * Fetch a task only if the current user may access it:
 *   - admins: any task
 *   - users : only tasks where tasks.user_id = their own id
 * Returns null for both "does not exist" and "not yours" so IDs cannot be probed.
 */
function find_accessible_task(int $taskId): ?array
{
    $user = require_login();
    if ($user['role'] === 'admin') {
        $row = run('SELECT t.*, u.name AS owner_name FROM tasks t JOIN users u ON u.id = t.user_id WHERE t.id = ?', [$taskId])->fetch();
    } else {
        $row = run('SELECT t.*, u.name AS owner_name FROM tasks t JOIN users u ON u.id = t.user_id WHERE t.id = ? AND t.user_id = ?', [$taskId, (int)$user['id']])->fetch();
    }
    return $row ?: null;
}

/* ---------- Task validation (server side) ---------- */
function validate_task(array $input): array
{
    $title  = trim((string)($input['title'] ?? ''));
    $desc   = trim((string)($input['description'] ?? ''));
    $status = (string)($input['status'] ?? 'Pending');
    $errors = [];

    if ($title === '') {
        $errors['title'] = 'Title is required.';
    } elseif (mb_strlen($title) > 150) {
        $errors['title'] = 'Title must be 150 characters or fewer.';
    }
    if (mb_strlen($desc) > 2000) {
        $errors['description'] = 'Description must be 2000 characters or fewer.';
    }
    if (!in_array($status, STATUSES, true)) {
        $errors['status'] = 'Please choose a valid status.';
    }
    return [['title' => $title, 'description' => $desc, 'status' => $status], $errors];
}

/* ---------- URL helper for dashboard filters ---------- */
function dashboard_url(array $params = []): string
{
    $allowed = [];
    $q = trim((string)($params['q'] ?? ''));
    if ($q !== '') {
        $allowed['q'] = mb_substr($q, 0, 100);
    }
    if (in_array($params['status'] ?? '', STATUSES, true)) {
        $allowed['status'] = $params['status'];
    }
    $page = (int)($params['page'] ?? 1);
    if ($page > 1) {
        $allowed['page'] = $page;
    }
    return 'dashboard.php' . ($allowed ? '?' . http_build_query($allowed) : '');
}
