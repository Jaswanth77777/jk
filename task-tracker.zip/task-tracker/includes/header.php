<?php
/** @var string $title */
$title = $title ?? 'Task Tracker';
$navUser = current_user();
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> - Task Tracker</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <div class="container bar">
    <a class="brand" href="<?= $navUser ? 'dashboard.php' : 'login.php' ?>">&#10003; Task Tracker</a>
    <nav>
      <?php if ($navUser): ?>
        <span class="who"><?= e($navUser['name']) ?> <span class="pill role-<?= e($navUser['role']) ?>"><?= e($navUser['role']) ?></span></span>
        <form method="post" action="logout.php" class="inline">
          <?= csrf_field() ?>
          <button type="submit" class="btn btn-small btn-ghost">Log out</button>
        </form>
      <?php else: ?>
        <a href="login.php">Log in</a>
        <a href="register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
<?php foreach (take_flashes() as $f): ?>
  <div class="alert alert-<?= e($f['type']) ?>" role="alert"><?= e($f['message']) ?></div>
<?php endforeach; ?>
