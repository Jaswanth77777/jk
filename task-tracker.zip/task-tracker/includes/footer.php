</main>
<footer class="container foot">Task Tracker &middot; RTIH Intern Assignment</footer>
<script src="assets/app.js"></script>
</body>
</html>
