<?php
require __DIR__ . '/includes/bootstrap.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    /* Step 2: user confirmed -> delete (POST + CSRF + ownership check). */
    csrf_verify();
    $task = find_accessible_task((int)($_POST['id'] ?? 0));
    if ($task === null) {
        render_error(404, 'Task not found.');
    }

    if ($user['role'] === 'admin') {
        run('DELETE FROM tasks WHERE id = ?', [(int)$task['id']]);
    } else {
        run('DELETE FROM tasks WHERE id = ? AND user_id = ?', [(int)$task['id'], (int)$user['id']]);
    }
    flash('success', 'Task "' . $task['title'] . '" was deleted.');
    redirect('dashboard.php');
}

/* Step 1: GET only shows a confirmation page - it never deletes anything. */
$task = find_accessible_task((int)($_GET['id'] ?? 0));
if ($task === null) {
    render_error(404, 'Task not found.');
}

$title = 'Delete task';
require __DIR__ . '/includes/header.php';
?>
<div class="card narrow">
  <h1>Delete this task?</h1>
  <p>You are about to permanently delete:</p>
  <p class="quote"><strong><?= e($task['title']) ?></strong></p>
  <p class="muted">This cannot be undone.</p>
  <form method="post" action="task_delete.php" class="actions">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$task['id'] ?>">
    <button type="submit" class="btn btn-danger">Yes, delete</button>
    <a class="btn btn-ghost" href="dashboard.php">Cancel</a>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
